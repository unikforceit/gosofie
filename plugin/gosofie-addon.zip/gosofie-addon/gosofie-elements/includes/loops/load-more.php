	
<div class="xlpagi pagi">
	 <span data-dir="more" class="ash_loadmore"><?php _e('Load more','king');?></span>
</div>

